<?php
//define('DB_SERVER', 'localhost');
//define('DB_USERNAME', 'root');
//define('DB_PASSWORD', '');
//define('DB_NAME', 'isp_ys96');
 
/* Attempt to connect to MySQL database */
//$mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
//$mysqli = new mysqli('localhost', 'root', '', 'isp_ys96');
//$mysqli = mysqli_connect('database-2.cstibm4pl4qd.us-east-2.rds.amazonaws.com:3306', 'admin', 'adminpassword', 'database_2');
$mysqli = new mysqli('database-2.cstibm4pl4qd.us-east-2.rds.amazonaws.com:3306', 'admin', 'adminpassword', 'database-2');

//Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
//if (mysqli_connect_errno()) {
//  printf("Connect failed: %s\n", mysqli_connect_error());
//  exit();
//}
?>